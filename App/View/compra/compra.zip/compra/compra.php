<!DOCTYPE html>
<html>

<head>
<title> Compra IPPLUG </title>
<link rel="stylesheet" href="compra.css" />
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">  
<link rel="stylesheet" href="assets/css/main.css" />
</head>


<body>
    <!-- Header -->
        <header id="header" class="alt">
                <a href="#menu" style=" padding: 0px 0px 0px 25px; background-color: black; border-radius: 40px 0px 0px 40px; "> Menu &nbsp; </a>
        </header>

    <!-- Nav -->
        <nav id="menu">
            <ul class="links">
                <li><a href="?page=home"> <img src="assets/css/home.png" width="14.7px" height="14.7px"> &nbsp; Início. </a></li>
                <li><a href="?page=compra"> <img src="assets/css/cart.png" width="14.7px" height="14.7px"> &nbsp; Comprar sua IP-Plug. </a></li>
                <li><a href="?page=usuario"> <img src="assets/css/door.png" width="14.7px" height="14.7px"> &nbsp; Login IP-Plug. </a></li>
                <li><a href="?page=usuario&action=cadastro"> <img src="assets/css/use.png" width="14.7px" height="14.7px"> &nbsp; Fazer Cadastro. </a></li>
              
<li> <a href="https://developer.spotify.com/legal/third-party-licenses/"><center>  </br></br> <img src="http://www.campaignbrief.com/spotify-connect.png" width="250" > <iframe src="https://open.spotify.com/embed/user/obbjwl1j5tj5o6xbus0imv2pf/playlist/4KMDhTNz2QqcKChMzf0X1E" width="250" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media" style="border-radius: 1px; border: 1px solid black;"> </iframe> Copyright © 2018 Spotify Ltd <center></a></li>
              
            </ul>
        </nav>
<center>

</br></br></br></br>
<div class="container center centro">

</br>
<div class="login-block" style="height: 1070px;"> <!-- A brincadeira da Comprs Come�a Aqui, area de inserir username(email) e senha -->

</br><center><a> <img src="img/ipat1.png" width="235px" height="95px"></a></center></br>
  <h1>COMPRAR SUA IPPLUG</h1>
 
  </br>

<div>
<img src="http://cdn.onlinewebfonts.com/svg/img_453163.png" style="width: 150px; height: 100px ">
<p style="font-size: 16px; font-weight: normal; color: #ffffff; border: solid 2px #fff; background-color: #00A1D5; width: 90%; padding: 15px; height: 100%; border-radius: 20px;"> Este Projeto ainda se encontra em etapa de desenvolvimento, <br/> caso deseje adquirir um de nossos projetos, entre em contanto nas plataformas abaixo. </p>
</div>

</br></br>
<b>Fale Conosco:</b>
</br></br>
<div style="border: solid 0.5px #B0B0B0; width: 95%; "></div>



</br><a style="font-size: 20px; color: #676767; font-weight: bolder; text-decoration:none; "><img src="http://pluspng.com/img-png/whatsapp-png-whatsapp-logo-png-1000.png" width="50px" height="50px"></br> Whatsapp:</a></br>+55 21 99878-2250</br>+55 21 97449-8488</br>+55 21 96753-9522</br>+55 21 98567-6244</br></br><div style="border: solid 0.5px #B0B0B0; width: 95%; "></div></br>

</br><a href="https://www.facebook.com/ipplug/" style="font-size: 20px; color: #676767; font-weight: bolder; text-decoration:none;  "><img src="https://i0.wp.com/blog.lojadatatuagem.com.br/wp-content/uploads/2017/05/facebook-transparent-logo-png-0.png?fit=1600%2C1600" width="40px" height="40px"></br>Facebook:</a></br> facebook.com/ipplug </br></br><div style="border: solid 0.5px #B0B0B0; width: 95%; "></div></br>

</br><a style="font-size: 20px; color: #676767; font-weight: bolder; text-decoration:none; "><img src="http://pngimg.com/uploads/email/email_PNG11.png" width="60px" height="40px"> </br> E-mail:</a></br>ipplug.inc@gmail.com </br></br><div style="border: solid 0.5px #B0B0B0; width: 95%; "></div></br>	

</br>

</div></br>
</div></br></br> <!-- A brincadeira do Login Termina Aqui -->
<!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/skel.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</center>
</html>



